# BiliBili - Huber_HaYu
## 运放芯片及路由处理，勿动！
if audio_chip_set | grep -q 'aw882'; then
    audio_chip_set "aw882xx_copp_switch" Disable
    audio_chip_set "aw_dev_1_prof" Music
    audio_chip_set "aw_dev_0_prof" Music
fi
if [ "$NAME" != "zeus" ] || [ "$NAME" != "unicorn" ]; then
    if audio_chip_set | grep -q 'RX_RX0 Digital Volume'; then
        audio_chip_set "RX_RX0 Digital Volume" $v
        audio_chip_set "RX_RX1 Digital Volume" $v
        audio_chip_set "RX_RX2 Digital Volume" $v
    fi
    if audio_chip_set | grep -q 'DEC0 MODE'; then
        audio_chip_set "DEC0 MODE" ADC_HIGH_PERF
        audio_chip_set "DEC1 MODE" ADC_HIGH_PERF
        audio_chip_set "DEC2 MODE" ADC_HIGH_PERF
        audio_chip_set "DEC3 MODE" ADC_HIGH_PERF
        audio_chip_set "DEC4 MODE" ADC_HIGH_PERF
        audio_chip_set "DEC5 MODE" ADC_HIGH_PERF
        audio_chip_set "DEC6 MODE" ADC_HIGH_PERF
        audio_chip_set "DEC7 MODE" ADC_HIGH_PERF
        echo "ok"
    fi
else
    audio_chip_set "BL Boost Target Voltage" 5
    audio_chip_set "BH Boost Target Voltage" 2
    audio_chip_set "TL Boost Target Voltage" 5
    audio_chip_set "TH Boost Target Voltage" 2
fi
if [ "$NAME" != "cas" ]; then
    tinymix "AMP PCM Gain" 16
    tinymix "RCV AMP PCM Gain" 20
    tinymix "Boost Target Voltage" 10
    tinymix "RCV Boost Target Voltage" 5
fi
## 运放芯片及路由处理，勿动！