#!/bin/sh

mv $MODPATH/·/Gen1 $MODPATH/system/vendor/etc/audio
mv $MODPATH/·/Gen2 $MODPATH/system/vendor/etc/audio
mv $MODPATH/·/Gen3 $MODPATH/system/vendor/etc/audio
