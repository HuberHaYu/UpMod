# Mi-HyperOS-AudioIO

## CN    
用于提升设备音频性能，针对于小米/红米设备（Magisk/Ksu都可）    
兼容安卓12+，确保OS版本为MIUI13及以上（包括HyperOS）    

## EN    
This Magisk Module improves your device's audio performance by optimizing sound quality and enhancing audio processing.(For Xiaomi/Redmi Device)    
Compatible only with Android 12+ and requires MIUI 13 or higher (including HyperOS).    
